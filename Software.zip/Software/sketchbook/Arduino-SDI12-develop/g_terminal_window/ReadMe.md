# Example G: Using the Arduino as a command terminal for SDI-12 sensors.

This is a simple demonstration of the SDI-12 library for Arduino.

It's purpose is to allow a user to interact with an SDI-12 sensor directly, issuing commands through a serial terminal window.
